#The square is not a Lo Shu Magic Square.
![image](https://user-images.githubusercontent.com/83244882/221413167-9f2da845-5e8a-470c-8e5c-5c443a035389.png)
#The square is a Lo Shu Magic Square.
![image](https://user-images.githubusercontent.com/83244882/221413251-e3d1703d-fe02-41c5-b398-958e14463f58.png)
