# The patient was an in-patient
![image](https://user-images.githubusercontent.com/83244882/221417585-4d82f213-6551-4db9-85d5-c42a69a17f60.png)
# The patient was an out-patient
![image](https://user-images.githubusercontent.com/83244882/221417672-abe1fafb-6d8b-4a26-8d00-8a94abff84da.png)
